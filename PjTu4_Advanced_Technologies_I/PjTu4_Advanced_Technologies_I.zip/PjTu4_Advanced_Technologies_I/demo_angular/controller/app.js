// Define the `todumvc` module
var phonecatApp = angular.module('todomvc', []);

// Define the `TodoCtrl` controller on the `todomvc` module
phonecatApp.controller('TodoCtrl', function PhoneListController($scope) {
  $scope.phones = [
    {
      name: 'Nexus S',
      snippet: 'Fast just got faster with Nexus S.'
    }, {
      name: 'Motorola XOOM with Wi-Fi',
      snippet: 'The Next, Next Generation tablet.'
    }, {
      name: 'MOTOROLA XOOM',
      snippet: 'The Next, Next Generation tablet.'
    }
  ];
});




