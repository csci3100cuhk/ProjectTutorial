// Used for avoiding dojo/cache from being loaded
define(function () {});
