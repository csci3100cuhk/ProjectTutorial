var browser_1 = require('angular2/platform/browser');
var app_1 = require('./app');
var store_1 = require('./services/store');
browser_1.bootstrap(app_1.default, [store_1.TodoStore]);
//# sourceMappingURL=bootstrap.js.map